# Laboratório 2 — Raio-X

Árvore: app/src/main/java contém MainActivity; app/src/main/res/layout/activity_main.xml contém a interface; app/src/main/res/values/strings.xml contém os textos; AndroidManifest.xml declara o aplicativo e a Activity; app/build.gradle.kts configura o módulo.

Recursos: R.layout.activity_main vem do XML de layout e é usado em setContentView; R.id.status vem do id no layout e é usado em findViewById; R.string.status_estrutura vem de strings.xml e é usado em setText. O título está em strings.xml, é referenciado pelo layout e aparece na tela.

Configuração preparada: namespace e applicationId br.edu.flamingo.mobile.unidade02; compileSdk 35; minSdk 24; targetSdk 35. minSdk determina a versão mínima suportada. Dependência declarada: implementation("androidx.core:core:1.13.1"). A biblioteca AndroidX Core fornece utilitários de compatibilidade para APIs Android; ela foi incluída como exemplo para a análise solicitada.

Para alterar texto estático, consulte strings.xml. Para adicionar biblioteca, consulte app/build.gradle.kts. Manifest declara componentes e configurações do aplicativo. A classe R referencia os recursos gerados no build. Captura da aplicação e evidência de build dependem de execução real.
