plugins { id("com.android.application") }
android {
    namespace = "br.edu.flamingo.mobile.unidade02"
    compileSdk = 35
    defaultConfig { applicationId = "br.edu.flamingo.mobile.unidade02"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies { implementation("androidx.core:core:1.13.1") }
