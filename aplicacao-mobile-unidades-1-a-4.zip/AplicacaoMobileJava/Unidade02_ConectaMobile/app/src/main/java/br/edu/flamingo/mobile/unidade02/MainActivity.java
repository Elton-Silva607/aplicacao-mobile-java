package br.edu.flamingo.mobile.unidade02;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle estado) {
        super.onCreate(estado);
        setContentView(R.layout.activity_main);
        TextView status = findViewById(R.id.status);
        findViewById(R.id.acessar).setOnClickListener(v -> status.setText(R.string.status_estrutura));
    }
}
