package br.edu.flamingo.mobile.unidade03;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle estado) {
        super.onCreate(estado);
        setContentView(R.layout.activity_main);
        findViewById(R.id.confirmar).setOnClickListener(v -> {
            String nome = ((EditText) findViewById(R.id.nome)).getText().toString();
            String email = ((EditText) findViewById(R.id.email)).getText().toString();
            String telefone = ((EditText) findViewById(R.id.telefone)).getText().toString();
            String empresa = ((EditText) findViewById(R.id.empresa)).getText().toString();
            String cargo = ((EditText) findViewById(R.id.cargo)).getText().toString();
            // Dados de demonstração: utilize valores fictícios nos testes.
            Log.d("EVENTO_TECH", "Nome: " + nome);
            Log.d("EVENTO_TECH", "Empresa: " + empresa);
            Log.d("EVENTO_TECH", "Área: " + cargo);
            Log.d("EVENTO_TECH", "Empresa e cargo informados: " + (!empresa.trim().isEmpty() && !cargo.trim().isEmpty()));
            ((TextView) findViewById(R.id.status)).setText(R.string.status_recebido);
        });
    }
}
