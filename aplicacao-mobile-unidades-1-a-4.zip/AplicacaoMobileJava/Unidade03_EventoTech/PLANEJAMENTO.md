# Laboratório 3 — Planejamento

Esboço: título EVENTO TECH → imagem → Cadastro de Participante → nome → e-mail → telefone → empresa → cargo → botão Confirmar inscrição → status. A tela rola verticalmente.

Melhorias: campos identificados por rótulos; inputType de e-mail e telefone; rolagem em telas menores; tamanhos em dp e sp; textos em strings.xml; botão com altura mínima de 48dp; descrição da imagem.

dp adapta dimensões à densidade e sp respeita a escala de fontes. A rolagem permite acessar os campos quando a área útil diminui. Execução em dois tamanhos, teclado, fonte ampliada, rotação, captura e Logcat ainda precisam de verificação em dispositivo ou emulador; não foram produzidas evidências.
