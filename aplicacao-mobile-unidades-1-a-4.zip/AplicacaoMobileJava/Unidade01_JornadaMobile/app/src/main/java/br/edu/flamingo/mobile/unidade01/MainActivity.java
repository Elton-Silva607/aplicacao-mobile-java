package br.edu.flamingo.mobile.unidade01;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int quantidadeCliques;
    private TextView contador, etapa;
    @Override public void onCreate(Bundle estado) {
        super.onCreate(estado);
        setContentView(R.layout.activity_main);
        contador = findViewById(R.id.contador);
        etapa = findViewById(R.id.etapa);
        if (estado != null) quantidadeCliques = estado.getInt("cliques", 0);
        atualizar();
        findViewById(R.id.botao).setOnClickListener(v -> {
            quantidadeCliques++;
            atualizar();
            Log.d("JORNADA_MOBILE", "Quantidade de interações: " + quantidadeCliques);
            if (quantidadeCliques == 5) Toast.makeText(this, R.string.concluido, Toast.LENGTH_LONG).show();
        });
    }
    private void atualizar() {
        contador.setText(getString(R.string.contador, quantidadeCliques));
        int mensagem = quantidadeCliques == 0 ? R.string.etapa_inicial : quantidadeCliques <= 3 ? R.string.explorando : quantidadeCliques <= 6 ? R.string.praticando : R.string.avancando;
        etapa.setText(mensagem);
    }
    @Override protected void onSaveInstanceState(Bundle estado) {
        estado.putInt("cliques", quantidadeCliques);
        super.onSaveInstanceState(estado);
    }
}
