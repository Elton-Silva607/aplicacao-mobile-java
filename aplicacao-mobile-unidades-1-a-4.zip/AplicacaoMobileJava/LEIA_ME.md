# Aplicação Mobile em Java — unidades 1 a 4

Cada pasta é um projeto Android independente, com código Java, layouts XML, Manifest e configuração Gradle. Abra a pasta da unidade como projeto Android. É necessário Android SDK com API 35, Gradle compatível, JDK 17 e acesso às dependências; este computador não apresentou Android SDK na localização padrão durante a verificação. Os arquivos Gradle não incluem wrapper. A unidade 3 usa ConstraintLayout.

Os códigos foram preparados a partir dos laboratórios e desafios da plataforma. Não foram executados no Android nem foram produzidas capturas, logs ou evidências de testes. Os questionários da plataforma não foram respondidos nem enviados.
