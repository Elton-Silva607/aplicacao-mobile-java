package br.edu.flamingo.mobile.unidade04;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
public class ObjetivoActivity extends CicloActivity {
    @Override protected String tag() { return "CICLO_OBJETIVO"; }
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(R.layout.activity_objetivo);
        findViewById(R.id.avancar).setOnClickListener(v -> {
            Intent i = new Intent(this, ResumoActivity.class);
            i.putExtra("nome", getIntent().getStringExtra("nome"));
            i.putExtra("area", getIntent().getStringExtra("area"));
            i.putExtra("objetivo", ((EditText)findViewById(R.id.objetivo)).getText().toString());
            startActivity(i);
        });
    }
}
