package br.edu.flamingo.mobile.unidade04;
import android.os.Bundle;
import android.widget.TextView;
public class ResumoActivity extends CicloActivity {
    @Override protected String tag() { return "CICLO_RESUMO"; }
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(R.layout.activity_resumo);
        ((TextView)findViewById(R.id.nome)).setText(getString(R.string.resumo_nome, valor("nome")));
        ((TextView)findViewById(R.id.area)).setText(getString(R.string.resumo_area, valor("area")));
        ((TextView)findViewById(R.id.objetivo)).setText(getString(R.string.resumo_objetivo, valor("objetivo")));
        findViewById(R.id.finalizar).setOnClickListener(v -> finish());
    }
    private String valor(String chave) { String valor = getIntent().getStringExtra(chave); return valor == null ? "" : valor; }
}
