package br.edu.flamingo.mobile.unidade04;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
public class PerfilActivity extends CicloActivity {
    @Override protected String tag() { return "CICLO_PERFIL"; }
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(R.layout.activity_perfil);
        findViewById(R.id.avancar).setOnClickListener(v -> {
            Intent i = new Intent(this, ObjetivoActivity.class);
            i.putExtra("nome", ((EditText)findViewById(R.id.nome)).getText().toString());
            i.putExtra("area", ((EditText)findViewById(R.id.area)).getText().toString());
            startActivity(i);
        });
    }
}
