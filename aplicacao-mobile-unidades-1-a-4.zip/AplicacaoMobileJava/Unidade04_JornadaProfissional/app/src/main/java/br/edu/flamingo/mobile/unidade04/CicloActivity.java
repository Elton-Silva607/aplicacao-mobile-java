package br.edu.flamingo.mobile.unidade04;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
public abstract class CicloActivity extends Activity {
    protected abstract String tag();
    @Override protected void onCreate(Bundle b) { super.onCreate(b); Log.d(tag(), "onCreate"); }
    @Override protected void onStart() { super.onStart(); Log.d(tag(), "onStart"); }
    @Override protected void onResume() { super.onResume(); Log.d(tag(), "onResume"); }
    @Override protected void onPause() { Log.d(tag(), "onPause"); super.onPause(); }
    @Override protected void onStop() { Log.d(tag(), "onStop"); super.onStop(); }
    @Override protected void onRestart() { super.onRestart(); Log.d(tag(), "onRestart"); }
    @Override protected void onDestroy() { Log.d(tag(), "onDestroy"); super.onDestroy(); }
}
