# Laboratório 4 — Investigação

Fluxo: Perfil → Objetivo → Resumo. O Intent transporta nome e área e depois objetivo; cada Activity escreve os métodos do ciclo de vida em sua própria TAG. A tela intermediária solicitada não apareceu nomeada separadamente no conteúdo consultado; foi implementada como Objetivo por causa do fluxo e dos dados exigidos.

Experimentos a registrar: abertura; avançar entre telas; Voltar; Home e retorno; rotação; finalizar resumo. Filtrar o Logcat por CICLO_PERFIL, CICLO_OBJETIVO ou CICLO_RESUMO. Não há observações reais ainda: executar os experimentos e anotar hipótese, sequência de logs e resultado antes de concluir o relatório.
